package com.example.sustainablelife;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Button backgroundButton = (Button)findViewById(R.id.backgroundButton);
        Button generateButton = (Button)findViewById(R.id.generateButton);
        Button changeButton = (Button)findViewById(R.id.changeButton);



        backgroundButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              Intent backgroundIntent = new Intent(getApplicationContext(), Background.class);
              startActivity(backgroundIntent);
            }
        });

        generateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent menuIntent = new Intent(getApplicationContext(), Generate.class);
                startActivity(menuIntent);
            }
        });


        changeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent changeIntent = new Intent(getApplicationContext(), Change.class);
                startActivity(changeIntent);
            }
        });



    }
}
