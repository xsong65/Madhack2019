package com.example.sustainablelife;

import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.content.Context;
import android.widget.TextView;

public class backgroundAdaptor extends BaseAdapter {

    LayoutInflater mInflator;
    ListView backgroundListView;
    String[] backgroundInfo;
    String[] sectionNum;

    //Constructor.
    public backgroundAdaptor(Context c,String[] background, String[] sectionsNum){

        this.backgroundInfo = background;
        this.sectionNum = sectionsNum;
        mInflator = (LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return backgroundInfo.length;
    }

    @Override
    public Object getItem(int position) {
        return backgroundInfo[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view = mInflator.inflate(R.layout.backgroundlistdetail, null);
        TextView infoDetail = (TextView)view.findViewById(R.id.introduction);
        TextView section = (TextView)view.findViewById(R.id.section1);

        String detail = backgroundInfo[position];
        String sec = sectionNum[position];

        infoDetail.setText(detail);
        section.setText(sec);

        return view;
    }


}
