package com.example.sustainablelife;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;

import java.util.ArrayList;

public class Generategraph extends AppCompatActivity {


    BarChart barChart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generategraph);

        Button back = (Button)findViewById(R.id.BackButton);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent menu = new Intent(getApplicationContext(), MenuActivity.class);
                startActivity(menu);
            }
        });


        barChart = (BarChart)findViewById(R.id.bargraph);

        ArrayList<BarEntry> barEntries = new ArrayList<>();

        int person = getIntent().getExtras().getInt("sum");

        barEntries.add(new BarEntry(0, person));
        ArrayList<BarEntry> barEntries1 = new ArrayList<>();
        barEntries1.add(new BarEntry(1, 9820));
        ArrayList<BarEntry> barEntries2 = new ArrayList<>();
        barEntries2.add(new BarEntry(2, 31480));

        BarDataSet barDataSet = new BarDataSet(barEntries, "Comparison");
/*
        ArrayList<String> types = new ArrayList<>();
        types.add("ME");
        types.add("WORLD");
                types.add("US");
*/


        ArrayList<IBarDataSet> types = new ArrayList<>();

        BarDataSet a = new BarDataSet(barEntries, "ME");
        a.setColor(Color.parseColor("#F44336"));
        types.add(a);

        BarDataSet b = new BarDataSet(barEntries1, "WORLD");
        types.add(b);
        b.setColors(Color.parseColor("#9C27B0"));

        BarDataSet c = new BarDataSet(barEntries2, "US");
        types.add(c);
        c.setColors(Color.parseColor("#e241f4"));


        BarData barData = new BarData(types);



        barChart.setData(barData);

        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(new String[]{""}));
        barChart.getAxisLeft().setAxisMinimum(0);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(9);
        xAxis.setCenterAxisLabels(true);
        xAxis.setGranularityEnabled(true);

        barData.setBarWidth(9.0f);
        barChart.getXAxis().setAxisMinimum(0);
        barChart.getXAxis().setAxisMaximum(0 + barChart.getBarData().getGroupWidth(3, 0.4f) * 3);
        barChart.groupBars(0, 3, 7.5f);


        barChart.getDescription().setText("UNIT: LBS");
        barChart.setDoubleTapToZoomEnabled(true);
        barChart.setTouchEnabled(true);
        barChart.setDragEnabled(true);
        barChart.setScaleEnabled(true);








    }


}
