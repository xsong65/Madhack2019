package com.example.sustainablelife;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.content.Intent;

public class Generate extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generate);

        /*
        if(name.getText() != null && electricityBill.getText() != null && gasBill.getText() != null && oilBill.getText() != null
                && mileage.getText() != null && numFlight.getText() != null && recycleNews.getText() != null && tins.getText() != null){
            submission = true;
        }

        */
    Button submit = (Button) findViewById(R.id.submissionButton);
    submit.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
try {
    EditText name = (EditText) findViewById(R.id.InputName);
    EditText electricityBill = (EditText) findViewById(R.id.electricityBill);
    EditText gasBill = (EditText) findViewById(R.id.gasBill);
    EditText oilBill = (EditText) findViewById(R.id.oilBill);
    EditText mileage = (EditText) findViewById(R.id.yearlyMileage);
    EditText numFlight = (EditText) findViewById(R.id.numFlight);
    EditText recycleNews = (EditText) findViewById(R.id.recycle);
    EditText tins = (EditText) findViewById(R.id.tins);

    String userName = name.getText().toString();
    int electricity = Integer.parseInt(electricityBill.getText().toString());
    int gas = Integer.parseInt(gasBill.getText().toString());
    int oil = Integer.parseInt(oilBill.getText().toString());
    int mile = Integer.parseInt(mileage.getText().toString());
    int flight = Integer.parseInt(numFlight.getText().toString());
    int news = Integer.parseInt(recycleNews.getText().toString());
    int tin = Integer.parseInt(tins.getText().toString());

    int all = electricity + gas + oil + mile + flight + news + tin;
    Intent next = new Intent(getApplicationContext(), Generategraph.class);
    next.putExtra("name", userName);
    next.putExtra("elec", electricity);
    next.putExtra("gas", gas);
    next.putExtra("oil", oil);
    next.putExtra("mile", mile);
    next.putExtra("numf", flight);
    next.putExtra("rec", news);
    next.putExtra("tin", tin);
    next.putExtra("sum", all);


    startActivity(next);
}catch(NullPointerException e0){

}
        }
    });




    }
}
