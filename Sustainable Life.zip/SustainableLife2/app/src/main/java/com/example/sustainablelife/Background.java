package com.example.sustainablelife;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.res.Resources;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.content.Intent;

public class Background extends AppCompatActivity {

    ListView backgroundListView;
    String[] backgroundInfo;
    String[] sectionNum;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_background);


        Resources res = getResources();
        backgroundListView = (ListView)findViewById(R.id.BackgroundListView);

        backgroundInfo = res.getStringArray(R.array.BackgroundSections);
        sectionNum = res.getStringArray(R.array.sectionNumber);

        backgroundAdaptor backgroundadaptor = new backgroundAdaptor(this, backgroundInfo, sectionNum);
        backgroundListView.setAdapter(backgroundadaptor);


        backgroundListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = null;

                switch(position){
                    case 0:
                        intent = new Intent(getApplicationContext(), Section1Detail.class);
                        break;
                    case 1:
                        intent = new Intent(getApplicationContext(), Section2Detail.class);
                        break;
                    case 2:
                        intent = new Intent(getApplicationContext(), Section3Detail.class);
                        break;
                    case 3:
                        intent = new Intent(getApplicationContext(), Section4Detail.class);
                        break;
                }

                     if(intent != null) {
                         startActivity(intent);
                     }

            }
        });



    }
}
